import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bajupria',
  templateUrl: './bajupria.page.html',
  styleUrls: ['./bajupria.page.scss'],
})
export class BajupriaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  
}
