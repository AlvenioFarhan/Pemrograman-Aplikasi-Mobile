import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tambah',
  templateUrl: './tambah.page.html',
  styleUrls: ['./tambah.page.scss'],
})
export class TambahPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
