import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-celana',
  templateUrl: './celana.page.html',
  styleUrls: ['./celana.page.scss'],
})
export class CelanaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
