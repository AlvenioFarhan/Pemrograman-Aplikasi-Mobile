import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detil-komentar',
  templateUrl: './detil-komentar.page.html',
  styleUrls: ['./detil-komentar.page.scss'],
})
export class DetilKomentarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
