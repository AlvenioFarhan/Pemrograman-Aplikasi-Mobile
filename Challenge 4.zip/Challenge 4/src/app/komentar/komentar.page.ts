import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-komentar',
  templateUrl: './komentar.page.html',
  styleUrls: ['./komentar.page.scss'],
})
export class KomentarPage  {

  constructor() { }

  ngOnInit() {
  }

}
