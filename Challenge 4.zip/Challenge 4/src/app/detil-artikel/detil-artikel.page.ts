import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detil-artikel',
  templateUrl: './detil-artikel.page.html',
  styleUrls: ['./detil-artikel.page.scss'],
})
export class DetilArtikelPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
