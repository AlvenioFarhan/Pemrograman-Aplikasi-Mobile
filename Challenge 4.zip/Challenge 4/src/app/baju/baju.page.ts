import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baju',
  templateUrl: './baju.page.html',
  styleUrls: ['./baju.page.scss'],
})
export class BajuPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  
}
